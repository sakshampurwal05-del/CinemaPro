"""
Simple splash screen with loading animation.
"""
import customtkinter as ctk

class SplashScreen(ctk.CTkToplevel):
    def __init__(self, parent, duration=1500):
        super().__init__(parent)
        self.duration = duration
        self.overrideredirect(True)
        self.geometry("500x300")
        self.configure(fg_color="#0f1724")

        self.label = ctk.CTkLabel(self, text="CinemaPro", font=ctk.CTkFont(size=28, weight="bold"), text_color="#f8fafc")
        self.label.place(relx=0.5, rely=0.4, anchor="center")

        self.sub = ctk.CTkLabel(self, text="Premium Movie Booking", text_color="#cbd5e1")
        self.sub.place(relx=0.5, rely=0.55, anchor="center")

        self.progress = ctk.CTkProgressBar(self, orientation="horizontal")
        self.progress.place(relx=0.1, rely=0.78, relwidth=0.8)
        self.after(50, self._animate)

    def _animate(self):
        val = 0.0
        step = 0.02
        def tick():
            nonlocal val
            val += step
            self.progress.set(min(val, 1.0))
            if val < 1.0:
                self.after(40, tick)
            else:
                self.destroy()
        tick()
