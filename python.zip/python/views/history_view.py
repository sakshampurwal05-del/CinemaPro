"""
Booking history screen: lists previous bookings from DB.
"""
import customtkinter as ctk
from models.booking import list_bookings

class HistoryView(ctk.CTkFrame):
    def __init__(self, parent, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)
        self._build()

    def _build(self):
        header = ctk.CTkLabel(self, text="Booking History", font=ctk.CTkFont(size=18, weight="bold"))
        header.pack(pady=12)

        container = ctk.CTkScrollableFrame(self, height=400)
        container.pack(fill="both", expand=True, padx=12, pady=12)

        bookings = list_bookings()
        for b in bookings:
            card = ctk.CTkFrame(container, corner_radius=10)
            card.pack(fill="x", pady=8, padx=8)
            t = ctk.CTkLabel(card, text=f"{b['movie_title']} — {b['customer_name']}", font=ctk.CTkFont(weight="bold"))
            t.pack(anchor="w", padx=12, pady=(8,0))
            info = ctk.CTkLabel(card, text=f"Seats: {', '.join(b['seats'])} | At: {b['booked_at']}")
            info.pack(anchor="w", padx=12, pady=(0,8))
