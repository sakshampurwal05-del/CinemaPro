"""
Home screen: show featured movies and quick actions.
"""
import customtkinter as ctk
from models.movie import list_movies


class HomeView(ctk.CTkFrame):
    def __init__(self, parent, navigate_to_booking, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)
        self.navigate_to_booking = navigate_to_booking
        self._build()

    def _build(self):
        header = ctk.CTkLabel(self, text="Now Showing", font=ctk.CTkFont(size=20, weight="bold"))
        header.pack(pady=(12, 8))

        movies = list_movies()

        # Use a scrollable frame so long movie lists show a scrollbar
        container = ctk.CTkScrollableFrame(self, height=480)
        container.pack(fill="both", expand=True, padx=12, pady=12)

        # add cards inside the scrollable frame
        for m in movies:
            card = ctk.CTkFrame(container, corner_radius=12, fg_color="#0b1220")
            card.pack(fill="x", pady=8, padx=8)
            t = ctk.CTkLabel(card, text=m['title'], font=ctk.CTkFont(size=14, weight="bold"))
            t.pack(side="left", padx=12, pady=12)
            btn = ctk.CTkButton(card, text="Book", width=90, command=lambda mid=m['id']: self.navigate_to_booking(mid))
            btn.pack(side="right", padx=12, pady=12)
