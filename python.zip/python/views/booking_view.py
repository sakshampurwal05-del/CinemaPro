"""
Booking screen: movie selector, seat grid, customer form, preview and confirm.
"""
import customtkinter as ctk
from models.movie import list_movies, get_movie
from models.booking import get_booked_seats
from controllers.booking_controller import create_ticket
from datetime import datetime
import tkinter as tk
import tkinter.messagebox as mb

class BookingView(ctk.CTkFrame):
    def __init__(self, parent, *args, movie_id=None, **kwargs):
        super().__init__(parent, *args, **kwargs)
        self.selected_movie_id = movie_id
        self.selected_seats = set()
        self.movie = None
        self._build()

    def _build(self):
        top = ctk.CTkFrame(self)
        top.pack(fill="x", padx=12, pady=12)

        movies = list_movies()
        self.movie_var = ctk.StringVar()
        opts = [f"{m['id']}: {m['title']}" for m in movies]
        if opts:
            self.movie_var.set(opts[0])
            if self.selected_movie_id:
                for opt in opts:
                    if opt.startswith(str(self.selected_movie_id)+":"):
                        self.movie_var.set(opt)
                        break

        self.dropdown = ctk.CTkOptionMenu(top, values=opts, variable=self.movie_var, command=self._on_movie_change)
        self.dropdown.pack(side="left", padx=(0,12))

        self.name_entry = ctk.CTkEntry(top, placeholder_text="Your name")
        self.name_entry.pack(side="left", padx=(0,12))

        self.book_btn = ctk.CTkButton(top, text="Confirm Booking", command=self._confirm_booking)
        self.book_btn.pack(side="right")

        # seat area
        self.seat_frame = ctk.CTkFrame(self)
        self.seat_frame.pack(fill="both", expand=True, padx=12, pady=12)

        # load first movie
        self._on_movie_change(self.movie_var.get())

    def _on_movie_change(self, selection):
        if not selection:
            return
        movie_id = int(selection.split(":")[0])
        self.movie = get_movie(movie_id)
        self.selected_movie_id = movie_id
        self._render_seats()

    def _render_seats(self):
        for child in self.seat_frame.winfo_children():
            child.destroy()

        rows = self.movie.get('total_rows', 8)
        cols = self.movie.get('total_cols', 12)
        booked = set(get_booked_seats(self.selected_movie_id))

        label = ctk.CTkLabel(self.seat_frame, text=f"Select Seats for {self.movie['title']}")
        label.pack(pady=(4,8))

        grid = ctk.CTkFrame(self.seat_frame)
        grid.pack()

        for r in range(rows):
            for c in range(cols):
                seat_label = f"{chr(65+r)}{c+1}"
                btn = ctk.CTkButton(grid, text=seat_label, width=48, height=36, command=lambda s=seat_label: self._toggle_seat(s))
                if seat_label in booked:
                    btn.configure(state="disabled", fg_color="#6b7280")
                btn.grid(row=r, column=c, padx=4, pady=4)

        self.count_label = ctk.CTkLabel(self.seat_frame, text="Selected: 0")
        self.count_label.pack(pady=8)

    def _toggle_seat(self, seat):
        if seat in self.selected_seats:
            self.selected_seats.remove(seat)
        else:
            self.selected_seats.add(seat)
        self.count_label.configure(text=f"Selected: {len(self.selected_seats)}")

    def _confirm_booking(self):
        name = self.name_entry.get().strip()
        if not name:
            mb.showerror("Error", "Please enter your name")
            return
        if not self.selected_seats:
            mb.showerror("Error", "Please select at least one seat")
            return

        try:
            result = create_ticket(self.selected_movie_id, name, sorted(list(self.selected_seats)))
        except Exception as e:
            mb.showerror("Booking Error", str(e))
            return

        # show success with path
        msg = f"Booked {len(self.selected_seats)} seats. Ticket saved to:\n{result['pdf_path']}"
        mb.showinfo("Booking Confirmed", msg)
        # reset selection and refresh seat map
        self.selected_seats.clear()
        self._render_seats()
