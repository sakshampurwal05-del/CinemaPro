"""
About/Help screen with app details and quick tips.
"""
import customtkinter as ctk

class AboutView(ctk.CTkFrame):
    def __init__(self, parent, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)
        self._build()

    def _build(self):
        h = ctk.CTkLabel(self, text="About CinemaPro", font=ctk.CTkFont(size=18, weight="bold"))
        h.pack(pady=12)

        txt = (
            "CinemaPro is a premium movie ticketing demo built with CustomTkinter.\n"
            "Features: modern UI, seat selection, PDF ticket with QR code, booking history.\n\n"
            "Tips:\n- Select seats from the grid.\n- Use 'Booking History' to review past tickets.\n- Add logo in resources/ and configure if desired."
        )
        body = ctk.CTkLabel(self, text=txt, justify="left")
        body.pack(padx=12, pady=8)
