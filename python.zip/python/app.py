"""
Main application entry: sets up CustomTkinter appearance, navigation, and view switching.

Run: `python app.py`
"""
import customtkinter as ctk
from views.splash import SplashScreen
from views.home_view import HomeView
from views.booking_view import BookingView
from views.history_view import HistoryView
from views.about_view import AboutView
from controllers.booking_controller import initialize_db, add_sample_movies_if_empty
import threading
import tkinter as tk
from pathlib import Path


def _center(win, w=900, h=600):
    ws = win.winfo_screenwidth()
    hs = win.winfo_screenheight()
    x = (ws // 2) - (w // 2)
    y = (hs // 2) - (h // 2)
    win.geometry(f"{w}x{h}+{x}+{y}")


class MainApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")
        self.title("CinemaPro — Premium Booking")
        _center(self, 1000, 700)
        self.minsize(800, 600)

        # top nav
        nav = ctk.CTkFrame(self, height=60, corner_radius=0)
        nav.pack(fill="x")
        logo = ctk.CTkLabel(nav, text="CinemaPro", font=ctk.CTkFont(size=18, weight="bold"))
        logo.pack(side="left", padx=12)

        btn_home = ctk.CTkButton(nav, text="Home", command=lambda: self.show_view('home'))
        btn_home.pack(side="left", padx=8)
        btn_booking = ctk.CTkButton(nav, text="Book", command=lambda: self.show_view('book'))
        btn_booking.pack(side="left", padx=8)
        btn_history = ctk.CTkButton(nav, text="History", command=lambda: self.show_view('history'))
        btn_history.pack(side="left", padx=8)
        btn_about = ctk.CTkButton(nav, text="About", command=lambda: self.show_view('about'))
        btn_about.pack(side="left", padx=8)

        # content container
        self.container = ctk.CTkFrame(self)
        self.container.pack(fill="both", expand=True, padx=12, pady=12)

        # views
        self.views = {}
        self.views['home'] = HomeView(self.container, navigate_to_booking=lambda mid: self.show_view('book', movie_id=mid))
        self.views['book'] = BookingView(self.container)
        self.views['history'] = HistoryView(self.container)
        self.views['about'] = AboutView(self.container)

        for v in self.views.values():
            v.place(relx=0, rely=0, relwidth=1, relheight=1)

        # start on home
        self.show_view('home')

    def show_view(self, key, **kwargs):
        # optionally pass movie_id to booking view
        if key == 'book' and 'movie_id' in kwargs:
            self.views['book'].destroy()
            self.views['book'] = BookingView(self.container, movie_id=kwargs['movie_id'])
            self.views['book'].place(relx=0, rely=0, relwidth=1, relheight=1)

        for k, v in self.views.items():
            if k == key:
                v.lift()
            else:
                v.lower()


def start():
    # initialize DB in background to keep UI responsive
    initialize_db()
    add_sample_movies_if_empty()

    app = MainApp()

    # show splash
    splash = SplashScreen(app, duration=800)
    app.after(100, lambda: splash.deiconify())

    app.mainloop()


if __name__ == '__main__':
    start()
