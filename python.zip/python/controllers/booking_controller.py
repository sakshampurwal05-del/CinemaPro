"""
Controller for booking operations: validation, booking flow, PDF generation trigger.
"""
import uuid
from datetime import datetime
from models import booking as booking_model
from models import movie as movie_model
from utils import pdf_generator

def initialize_db():
    movie_model.init_movies_table()
    booking_model.init_bookings_table()

def add_sample_movies_if_empty():
    # Ensure the desired Bollywood trending list is present in the DB.
    existing = {m['title'] for m in movie_model.list_movies()}
    titles = [
        "Jawan", "Pathaan", "Dunki", "Animal", "Gadar 2", "Tiger 3",
        "Salaar (Hindi)", "Fighter", "Brahmastra", "Bhool Bhulaiyaa 2",
        "Adipurush", "OMG 2", "Rocky Aur Rani Ki Prem Kahani", "Shershaah", "Sooryavanshi",
        "Kisi Ka Bhai Kisi Ki Jaan", "Laal Singh Chaddha", "Sam Bahadur", "12th Fail", "Drishyam 2",
        "Bhediya", "Atrangi Re", "Satyaprem Ki Katha", "Vikram Vedha (Hindi)", "Bell Bottom",
        "Heropanti 2", "Major", "Chandigarh Kare Aashiqui", "Sardar Udham", "Badhaai Do",
        "Jayeshbhai Jordaar", "War", "Ek Villain Returns", "Radhe Shyam (Hindi)", "Luka Chuppi 2",
        "Stree 2", "Crew", "The Archies (Hindi)", "Freddy", "Govinda Naam Mera",
        "Madaari 2", "Tejas", "Chamkila", "Article 370", "Merry Christmas (Hindi)",
        "Bholaa", "Shaitan", "Jabariya Jodi 2", "Tanhaji", "Baaghi 3"
    ]
    # If the existing set is different from desired, replace the table to exactly match.
    desired_set = set(titles)
    if existing != desired_set:
        movie_model.replace_movies(titles)

def create_ticket(movie_id: int, customer_name: str, seats: list, logo_path: str = None) -> dict:
    """Perform validation, save booking, and generate PDF ticket.

    Returns dict with booking info and file path.
    """
    # basic validation
    if not customer_name or not seats:
        raise ValueError("Customer name and seats must be provided")

    # ensure movie exists
    movie = movie_model.get_movie(movie_id)
    if not movie:
        raise ValueError("Movie not found")

    # generate ticket id and timestamp
    ticket_id = str(uuid.uuid4())[:8].upper()
    now = datetime.utcnow().isoformat()

    # save booking to DB
    booking_id = booking_model.create_booking(ticket_id, movie_id, customer_name, seats, now)

    # generate PDF
    pdf_path = pdf_generator.generate_ticket_pdf(
        ticket_id=ticket_id,
        movie_title=movie['title'],
        customer_name=customer_name,
        seats=seats,
        booked_at=now,
        logo_path=logo_path,
    )

    return {
        "booking_id": booking_id,
        "ticket_id": ticket_id,
        "pdf_path": pdf_path,
    }
