"""
Movie model: handle movie records and seat configurations in SQLite.
"""
import sqlite3
from typing import List, Dict
from pathlib import Path

DB_PATH = Path("data/bookings.db")

def _get_conn():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn

def init_movies_table():
    conn = _get_conn()
    c = conn.cursor()
    c.execute(
        """
        CREATE TABLE IF NOT EXISTS movies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            total_rows INTEGER DEFAULT 8,
            total_cols INTEGER DEFAULT 12
        )
        """
    )
    conn.commit()
    conn.close()

def add_movie(title: str, rows: int = 8, cols: int = 12) -> int:
    conn = _get_conn()
    c = conn.cursor()
    c.execute("INSERT INTO movies (title, total_rows, total_cols) VALUES (?, ?, ?)", (title, rows, cols))
    movie_id = c.lastrowid
    conn.commit()
    conn.close()
    return movie_id

def replace_movies(titles: List[str], rows: int = 8, cols: int = 12):
    """Replace movies table contents with the provided list of titles.

    This wipes existing rows and inserts the given titles with default seating.
    """
    conn = _get_conn()
    c = conn.cursor()
    # remove existing rows
    c.execute("DELETE FROM movies")
    # insert the fresh list
    for t in titles:
        c.execute("INSERT INTO movies (title, total_rows, total_cols) VALUES (?, ?, ?)", (t, rows, cols))
    conn.commit()
    conn.close()

def list_movies() -> List[Dict]:
    conn = _get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM movies ORDER BY id DESC")
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows

def get_movie(movie_id: int) -> Dict:
    conn = _get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM movies WHERE id = ?", (movie_id,))
    r = c.fetchone()
    conn.close()
    return dict(r) if r else None
