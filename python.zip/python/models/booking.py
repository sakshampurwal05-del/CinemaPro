"""
Booking model: stores booking records and maps seat allocations.
"""
import sqlite3
from pathlib import Path
from typing import List, Dict
import json

DB_PATH = Path("data/bookings.db")

def _get_conn():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn

def init_bookings_table():
    conn = _get_conn()
    c = conn.cursor()
    c.execute(
        """
        CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticket_id TEXT NOT NULL,
            movie_id INTEGER,
            customer_name TEXT,
            seats_json TEXT,
            booked_at TEXT
        )
        """
    )
    conn.commit()
    conn.close()

def create_booking(ticket_id: str, movie_id: int, customer_name: str, seats: List[str], booked_at: str) -> int:
    conn = _get_conn()
    c = conn.cursor()
    seats_json = json.dumps(seats)
    c.execute("INSERT INTO bookings (ticket_id, movie_id, customer_name, seats_json, booked_at) VALUES (?, ?, ?, ?, ?)",
              (ticket_id, movie_id, customer_name, seats_json, booked_at))
    bid = c.lastrowid
    conn.commit()
    conn.close()
    return bid

def list_bookings() -> List[Dict]:
    conn = _get_conn()
    c = conn.cursor()
    c.execute("SELECT b.*, m.title as movie_title FROM bookings b LEFT JOIN movies m ON b.movie_id = m.id ORDER BY b.id DESC")
    rows = []
    for r in c.fetchall():
        d = dict(r)
        d['seats'] = json.loads(d.get('seats_json') or '[]')
        rows.append(d)
    conn.close()
    return rows

def get_booked_seats(movie_id: int) -> List[str]:
    conn = _get_conn()
    c = conn.cursor()
    c.execute("SELECT seats_json FROM bookings WHERE movie_id = ?", (movie_id,))
    seats = []
    for r in c.fetchall():
        arr = json.loads(r['seats_json']) if r['seats_json'] else []
        seats.extend(arr)
    conn.close()
    return seats
