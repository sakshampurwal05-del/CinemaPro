"""
Generate professional PDF tickets with QR codes and watermark using reportlab.
"""
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import landscape, A6
from reportlab.lib.units import mm
from reportlab.lib.utils import ImageReader
from datetime import datetime
from pathlib import Path
import qrcode
from io import BytesIO
from PIL import Image, ImageEnhance

OUT_DIR = Path("tickets")
OUT_DIR.mkdir(parents=True, exist_ok=True)

def _make_qr_image(data: str, size: int = 200) -> Image.Image:
    qr = qrcode.QRCode(box_size=4, border=1)
    qr.add_data(data)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white").convert("RGB")
    img = img.resize((size, size))
    return img

def generate_ticket_pdf(ticket_id: str, movie_title: str, customer_name: str, seats: list, booked_at: str, logo_path: str = None) -> str:
    """Create a landscape small-ticket PDF with watermark, logo, and QR code.

    Returns the path to the generated PDF.
    """
    filename = OUT_DIR / f"ticket_{ticket_id}.pdf"
    # Use small landscape size similar to ticket; A6 landscape works well.
    c = canvas.Canvas(str(filename), pagesize=landscape(A6))
    w, h = landscape(A6)

    # draw watermark text lightly
    c.saveState()
    c.setFont("Helvetica-Bold", 30)
    c.setFillGray(0.9)
    c.translate(w/2, h/2)
    c.rotate(30)
    c.drawCentredString(0, 0, "CINEMA TICKET")
    c.restoreState()

    # header: logo and title
    if logo_path:
        try:
            logo_im = Image.open(logo_path).convert("RGBA")
            logo_im.thumbnail((80, 40))
            bio = BytesIO()
            logo_im.save(bio, format="PNG")
            bio.seek(0)
            c.drawImage(ImageReader(bio), 10*mm, h - 20*mm, preserveAspectRatio=True, mask='auto')
        except Exception:
            pass

    c.setFont("Helvetica-Bold", 14)
    c.drawString(40*mm, h - 12*mm, movie_title)

    # ticket info block
    c.setFont("Helvetica", 10)
    c.drawString(10*mm, h - 30*mm, f"Ticket ID: {ticket_id}")
    c.drawString(10*mm, h - 36*mm, f"Customer: {customer_name}")
    c.drawString(10*mm, h - 42*mm, f"Seats: {', '.join(seats)}")
    c.drawString(10*mm, h - 48*mm, f"Booked At: {booked_at}")

    # QR code
    qr_img = _make_qr_image(f"{ticket_id}|{movie_title}|{','.join(seats)}")
    buf = BytesIO()
    qr_img.save(buf, format="PNG")
    buf.seek(0)
    qr_size = 40*mm
    c.drawImage(ImageReader(buf), w - qr_size - 6*mm, 10*mm, width=qr_size, height=qr_size)

    # decorative line / perforation
    c.setDash(3, 2)
    c.line(5*mm, h/2, w - 5*mm, h/2)

    c.showPage()
    c.save()
    return str(filename)
