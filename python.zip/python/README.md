# CinemaPro — Premium Movie Ticket Booking (CTk Edition)

This project is a refactor of a simple Tkinter movie ticket booking system into a premium-quality application using CustomTkinter.

Features:
- Modern UI with `customtkinter` (CTk)
- MVC-style layout: `models/`, `views/`, `controllers/`
- SQLite persistence (`data/bookings.db`)
- Seat selection grid with disabled booked seats
- PDF ticket generation (QR code, watermark, logo support)
- Splash screen, navigation bar, responsive layout

Run:

1. Create a virtual environment and install dependencies:
```powershell
python -m venv .venv; .\.venv\Scripts\Activate; pip install -r requirements.txt
```

2. Start app:
```powershell
python app.py
```

Notes:
- Place a logo image at `resources/logo.png` if you want it added to tickets.
- Some CTk messagebox utilities may vary by `customtkinter` version; if a runtime error occurs, replace `CTkMessageBox` usages with `tkinter.messagebox`.

Further enhancements are described at the bottom of this README.
