Resources folder - place logos, fonts and icons here.

- `logo.png` — theater/company logo used on ticket header (recommended 300x150 px)
- `font/` — custom fonts (optional)

Add your assets here and update paths in `app.py` or `utils/pdf_generator.py` as needed.
