import tkinter as tk
from tkinter import messagebox
from reportlab.pdfgen import canvas
from datetime import datetime

# Movie data
movies = {
    "Avengers: Endgame": 50,
    "Spider-Man: No Way Home": 40,
    "Interstellar": 30
}

# --- PDF Generation Function ---
def generate_pdf(name, movie, tickets):
    file_name = f"{name}_ticket.pdf"
    c = canvas.Canvas(file_name)

    c.setTitle("Movie Ticket")
    c.setFont("Helvetica-Bold", 22)
    c.drawString(200, 800, "🎟 MOVIE TICKET")

    c.setFont("Helvetica", 14)
    c.drawString(50, 750, f"Name: {name}")
    c.drawString(50, 720, f"Movie: {movie}")
    c.drawString(50, 690, f"Tickets: {tickets}")
    c.drawString(50, 660, f"Date: {datetime.now().strftime('%d-%m-%Y %H:%M')}")

    c.drawString(50, 620, "Enjoy Your Show! 🍿")
    c.line(40, 600, 550, 600)

    c.save()
    return file_name

# --- Booking Function ---
def book_ticket():
    name = entry_name.get()
    movie = movie_var.get()
    tickets = entry_tickets.get()

    if not name or not tickets:
        messagebox.showerror("Error", "Fill all fields!")
        return

    tickets = int(tickets)

    if tickets <= 0:
        messagebox.showerror("Error", "Enter a valid number of tickets!")
        return

    # Check seat availability
    if movies[movie] >= tickets:
        movies[movie] -= tickets

        pdf = generate_pdf(name, movie, tickets)
        messagebox.showinfo("Success", f"Tickets booked!\nPDF saved as: {pdf}")

        # Clear fields
        entry_name.delete(0, tk.END)
        entry_tickets.delete(0, tk.END)
    else:
        messagebox.showerror("Error", "Not enough seats available!")

# ------------------------------------
# 🌟 Tkinter GUI
# ------------------------------------

root = tk.Tk()
root.title("Movie Ticket Booking System")
root.geometry("420x380")
root.config(bg="#F2F2F2")

# Heading
title = tk.Label(root, text="🎬 Movie Ticket Booking System", 
                 font=("Arial", 18, "bold"), bg="#F2F2F2")
title.pack(pady=15)

# Name
tk.Label(root, text="Your Name:", font=("Arial", 13), bg="#F2F2F2").pack()
entry_name = tk.Entry(root, font=("Arial", 12), width=30)
entry_name.pack(pady=5)

# Movie dropdown
tk.Label(root, text="Select Movie:", font=("Arial", 13), bg="#F2F2F2").pack()
movie_var = tk.StringVar()
movie_var.set("Avengers: Endgame")

drop = tk.OptionMenu(root, movie_var, *movies.keys())
drop.config(font=("Arial", 12), width=25)
drop.pack(pady=5)

# Tickets
tk.Label(root, text="Number of Tickets:", font=("Arial", 13), bg="#F2F2F2").pack()
entry_tickets = tk.Entry(root, font=("Arial", 12), width=30)
entry_tickets.pack(pady=5)

# Book Button
btn = tk.Button(root, text="Book Ticket", font=("Arial", 14, "bold"),
                bg="#5A8DEE", fg="white", width=20, command=book_ticket)
btn.pack(pady=20)

root.mainloop()
